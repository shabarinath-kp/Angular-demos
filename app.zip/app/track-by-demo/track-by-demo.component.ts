import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-track-by-demo',
  templateUrl: './track-by-demo.component.html',
  styleUrls: ['./track-by-demo.component.css']
})
export class TrackByDemoComponent implements OnInit {
  employees: any[]; 
  constructor() { 

    this.employees = [ 
      { 
          code: '1', name: 'Tobia', gender: 'Female', 
          salary:  12345
      }, 
      { 
          code: '2', name: 'Evana', gender: 'Female', 
          salary:  2342
      }, 
      { 
          code: '3', name: 'Ruby', gender: 'Female', 
          salary:  54312
      }, 
      { 
          code: '4', name: 'Juri', gender: 'Male', 
          salary:  23535
      } 
  ]; 
  }

   

trackByEmpCode(index: number, employee: any): string 
           { 
                return employee.code; 
            } 

 

  ngOnInit() {
  }


 refreshData()
 {
  this.employees = [ 
    { 
        code: '1', name: 'Tobia', gender: 'Female', 
        salary:  12345
    }, 
    { 
        code: '2', name: 'Evana', gender: 'Female', 
        salary:  2342
    }, 
    { 
        code: '3', name: 'Ruby', gender: 'Female', 
        salary:  54312
    }, 
    { 
        code: '4', name: 'Juri', gender: 'Male', 
        salary:  23535
    } ,

    { 
      code: '5', name: 'alex', gender: 'Male', 
      salary:  23535
  } 
]; 
 }

addEmployees()
{
  this.employees.push(
    {
    code: '5', name: 'Pascal', gender: 'male', 
        salary: 31235 
  })
}


}
