import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-custom-binding-demo',
  templateUrl: './custom-binding-demo.component.html',
  styleUrls: ['./custom-binding-demo.component.css']
})
export class CustomBindingDemoComponent implements OnInit {

  count : number = 0;   

  @Output() counterChange :  EventEmitter<number>;
      constructor()
      {
       
          this.counterChange = new EventEmitter();
       
      }
   
   @Input() 
      get counter(){

          return this.count; 
      }


      set counter(val) {
          this.count = val;
          
        }
      increment(){

          this.count = this.count+1; 
          this.counterChange.emit(this.count);
      }

      decrement(){
          this.count = this.count - 1; 
          this.counterChange.emit(this.count);
      }

      ngOnInit(){}

}
