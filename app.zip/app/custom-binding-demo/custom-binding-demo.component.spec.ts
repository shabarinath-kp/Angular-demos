import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomBindingDemoComponent } from './custom-binding-demo.component';

describe('CustomBindingDemoComponent', () => {
  let component: CustomBindingDemoComponent;
  let fixture: ComponentFixture<CustomBindingDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomBindingDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomBindingDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
