import { Component, OnInit } from '@angular/core';
 

@Component({
  selector: 'app-bindings-demo',
  templateUrl: './bindings-demo.component.html',
  styleUrls: ['./bindings-demo.component.css']
})
export class BindingsDemoComponent implements OnInit {
  
  firstName:string="Alex";
  lastName:string="Paul";

  constructor() { }

  ngOnInit() {
  }


   sayHello()
   {
     alert ('hello');
   }


}
