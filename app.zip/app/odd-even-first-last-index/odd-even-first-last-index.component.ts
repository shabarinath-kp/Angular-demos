import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-odd-even-first-last-index',
  templateUrl: './odd-even-first-last-index.component.html',
  styleUrls: ['./odd-even-first-last-index.component.css']
})
export class OddEvenFirstLastIndexComponent implements OnInit {
  people = [
    { name: 'alex ', age: '44', salary: '2543' },
    { name: 'brad', age: '34', salary: '1233' },
    { name: 'Meclod', age: '67', salary: '7832' },
    { name: 'Dekins', age: '59', salary: '6732' },
    { name: 'Fluin', age: '37',salary: '3453' }
  ]
  constructor() { }

  ngOnInit() {
  }

}
