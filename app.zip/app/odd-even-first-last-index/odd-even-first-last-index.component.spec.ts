import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OddEvenFirstLastIndexComponent } from './odd-even-first-last-index.component';

describe('OddEvenFirstLastIndexComponent', () => {
  let component: OddEvenFirstLastIndexComponent;
  let fixture: ComponentFixture<OddEvenFirstLastIndexComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OddEvenFirstLastIndexComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OddEvenFirstLastIndexComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
