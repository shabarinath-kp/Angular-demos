import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attribute-binding-demo',
  templateUrl: './attribute-binding-demo.component.html',
  styleUrls: ['./attribute-binding-demo.component.css']
})
export class AttributeBindingDemoComponent implements OnInit {

  pageHeader: string = 'Emp Details';
  FirstName: string = 'Sam';
  LastName: string = 'Alex';
  Dept: string = 'admin';
  Mobile: number = 123;
  Gender: string = 'Male';
  Age: number = 43;
  ColumnSpan :number=2;

  constructor() { }

  ngOnInit() {
  }

}
