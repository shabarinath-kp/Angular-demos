import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngstyles-demo',
  templateUrl: './ngstyles-demo.component.html',
  styleUrls: ['./ngstyles-demo.component.css']
})
export class NgstylesDemoComponent implements OnInit {
  people: any[] = [
    {
      name: "Douglas  Pace",
      country: "UK"
    },
    {
      name: "Mcleod  Mueller",
      country: "USA"
    },
    {
      name: "Day  Meyers",
      country: "HK"
    },
    {
      name: "Aguirre  Ellis",
      country: "UK"
    },
    {
      name: "Cook  Tyson",
      country: "USA"
    }
  ];



  constructor() { }

  ngOnInit() {
  }

  getColor(country) {
    switch (country) {
      case "UK":
        return "green";
      case "USA":
        return "blue";
      case "HK":
        return "red";
    }
  }


}
