import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NgstylesDemoComponent } from './ngstyles-demo.component';

describe('NgstylesDemoComponent', () => {
  let component: NgstylesDemoComponent;
  let fixture: ComponentFixture<NgstylesDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgstylesDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgstylesDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
