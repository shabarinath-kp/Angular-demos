
import {Component} from '@angular/core';

@Component({
    selector:'first-cmp',
  
    template:
    `
    <h1> hello there </h1>
    <h3> first name is {{firstName}} </h3>
    <h3> last name is {{lastName}} </h3>
    `,   
   
    

})
export class FirstComponent
{
    firstName:string;
    lastName:string;

    constructor()
    {
        console.log("constructor of first cmp called");
        this.firstName="shabari";
        this.lastName="kp";
    }
}