import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {

  result:number=0;
  resultFrmChild:number;
  constructor() { }

  ngOnInit() {
  }

  generateRandom()
  {
    this.result=Math.random();
  }

 listenForDataFromChild(eventArgs)
 {
 this.resultFrmChild=eventArgs;
 }

}
