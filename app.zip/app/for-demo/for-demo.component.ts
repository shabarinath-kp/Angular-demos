import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-for-demo',
  templateUrl: './for-demo.component.html',
  styleUrls: ['./for-demo.component.css']
})
export class ForDemoComponent implements OnInit {

  people: any[] = [
    {
      "name": "Tobia",
      "age": 35
    },
    {
      "name": "Brad",
      "age": 32
    },
    {
      "name": "Andy",
      "age": 21
    },
    {
      "name": "Peter",
      "age": 34
    },
    {
      "name": "John",
      "age": 32
    }
  ];
  constructor() { }

  ngOnInit() {
  }

}
