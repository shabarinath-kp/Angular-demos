import { Component, OnInit,Input,EventEmitter,Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

 @Input() valFrmParent:number; //hold the data that is sent by the parent

 @Output() notify:EventEmitter<number> =new EventEmitter<number>(); 

  constructor() { }

  ngOnInit() {
  }

   fireCustomEvent()
   {
     this.notify.emit(Math.random());
   }


}
