import { ChangeColourDirective } from './change-colour.directive';

describe('ChangeColourDirective', () => {
  it('should create an instance', () => {
    const directive = new ChangeColourDirective();
    expect(directive).toBeTruthy();
  });
});
