import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NgclassDemosComponent } from './ngclass-demos.component';

describe('NgclassDemosComponent', () => {
  let component: NgclassDemosComponent;
  let fixture: ComponentFixture<NgclassDemosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgclassDemosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgclassDemosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
