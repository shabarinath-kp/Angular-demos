import { Directive,ElementRef,Renderer2 ,HostListener,Input} from '@angular/core';

@Directive({
  selector: '[appChangeColour]'
})
export class ChangeColourDirective {

  @Input('appChangeColour') highlightColor: string;  

  constructor(private el:ElementRef,private rd:Renderer2)
  
  {

  //  this.changeTheColour("red");
   }

  changeTheColour(c:string)
  {
    this.rd.setStyle(this.el.nativeElement,'color', c)
  }

  @HostListener('mouseenter') f1(){
    this.changeTheColour(this.highlightColor);
}

@HostListener('mouseleave') f2(){
    this.changeTheColour('blue');
}

}
