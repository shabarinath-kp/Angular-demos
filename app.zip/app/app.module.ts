import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FirstComponent } from './first.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { BindingsDemoComponent } from './bindings-demo/bindings-demo.component';
import { FormsModule } from '@angular/forms';
import { AttributeBindingDemoComponent } from './attribute-binding-demo/attribute-binding-demo.component';
import { BindingsDemo2Component } from './bindings-demo2/bindings-demo2.component';
import { CustomBindingDemoComponent } from './custom-binding-demo/custom-binding-demo.component';
import { StyleBindingDemoComponent } from './style-binding-demo/style-binding-demo.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { ForDemoComponent } from './for-demo/for-demo.component';
import { IfDemoComponent } from './if-demo/if-demo.component';
import { TrackByDemoComponent } from './track-by-demo/track-by-demo.component';
import { OddEvenFirstLastIndexComponent } from './odd-even-first-last-index/odd-even-first-last-index.component';
import { NgstylesDemoComponent } from './ngstyles-demo/ngstyles-demo.component';
import { NgclassDemosComponent } from './ngclass-demos/ngclass-demos.component';
import { ChangeColourDirective } from './change-colour.directive';

@NgModule({
  declarations: [
    AppComponent,
   FirstComponent,
   HeaderComponent,
   FooterComponent,
   BindingsDemoComponent,
   AttributeBindingDemoComponent,
   BindingsDemo2Component,
   CustomBindingDemoComponent,
   StyleBindingDemoComponent,
   ParentComponent,
   ChildComponent,
   ForDemoComponent,
   IfDemoComponent,
   TrackByDemoComponent,
   OddEvenFirstLastIndexComponent,
   NgstylesDemoComponent,
   NgclassDemosComponent,
   ChangeColourDirective
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
