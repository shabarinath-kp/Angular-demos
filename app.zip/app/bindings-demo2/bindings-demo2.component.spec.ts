import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BindingsDemo2Component } from './bindings-demo2.component';

describe('BindingsDemo2Component', () => {
  let component: BindingsDemo2Component;
  let fixture: ComponentFixture<BindingsDemo2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BindingsDemo2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BindingsDemo2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
