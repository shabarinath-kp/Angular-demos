import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bindings-demo2',
  templateUrl: './bindings-demo2.component.html',
  styleUrls: ['./bindings-demo2.component.css']
})
export class BindingsDemo2Component implements OnInit {
 color = 'red';
  size = 16;
  displayText = 'show-class';
  visible = true;
  constructor() { }

  toggle() {
    this.visible = !this.visible;
    this.displayText = this.visible ? 'show-class' : 'hide-class';
  }
  ngOnInit() {
  }

}
