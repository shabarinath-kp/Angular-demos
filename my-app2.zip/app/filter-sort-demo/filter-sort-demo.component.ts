import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filter-sort-demo',
  templateUrl: './filter-sort-demo.component.html',
  styleUrls: ['./filter-sort-demo.component.css']
})
export class FilterSortDemoComponent implements OnInit {
  songs = [
    {
      title: 'Song 1',
      likes: 1
    },

    {
      title: 'Song 2',
      likes: 4
    },

    {
      title: 'Song 3',
      likes: 77
    },

    {
      title: 'Song 4',
      likes: 234
    },


    {
      title: 'Song 5',
      likes: 503
    },
    {
      title: 'Song 6',
      likes: 101
    }
  ]
  constructor() { }

  ngOnInit() {
  }

}
