import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FilterSortDemoComponent } from './filter-sort-demo.component';

describe('FilterSortDemoComponent', () => {
  let component: FilterSortDemoComponent;
  let fixture: ComponentFixture<FilterSortDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FilterSortDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilterSortDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
