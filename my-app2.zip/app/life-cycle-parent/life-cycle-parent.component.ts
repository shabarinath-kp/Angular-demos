import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-life-cycle-parent',
  templateUrl: './life-cycle-parent.component.html',
  styleUrls: ['./life-cycle-parent.component.css']
})
export class LifeCycleParentComponent implements OnInit {
  message :number= 0;
  displayChild: boolean = false;
  
  constructor() { 
    setTimeout(() => this.hideChild(), 5000);
  }

  hideChild()

{
 this.displayChild=false;
} 

toggle() {
    this.displayChild = !this.displayChild;
  }
  ngOnInit() {
  }


  clickHandler(){    
    this.message =  Math.random();
  }

}
