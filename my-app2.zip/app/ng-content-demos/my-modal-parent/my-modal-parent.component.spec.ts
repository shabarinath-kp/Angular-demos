import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyModalParentComponent } from './my-modal-parent.component';

describe('MyModalParentComponent', () => {
  let component: MyModalParentComponent;
  let fixture: ComponentFixture<MyModalParentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyModalParentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyModalParentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
