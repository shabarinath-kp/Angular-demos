import { Component, OnInit ,ViewChild } from '@angular/core';
import {MyModalChildComponent   } from '../my-modal-child/my-modal-child.component';  
@Component({
  selector: 'app-my-modal-parent',
  templateUrl: './my-modal-parent.component.html',
  styleUrls: ['./my-modal-parent.component.css']
})
export class MyModalParentComponent implements OnInit {
  private caption: string = 'Custom Modal';  
  @ViewChild('modal',{static:true}) private _ctrlModal: MyModalChildComponent;  
  private fnOpenModal(): void {  
    this._ctrlModal.showModal();  
}  

private fnHideModal(): void {  
    this._ctrlModal.close();  
}  
  
  constructor() { }

  ngOnInit() {
  }

}
