import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyModalChildComponent } from './my-modal-child.component';

describe('MyModalChildComponent', () => {
  let component: MyModalChildComponent;
  let fixture: ComponentFixture<MyModalChildComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyModalChildComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyModalChildComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
