import { Component, OnInit,ViewChild, Input } from '@angular/core';

@Component({
  selector: 'app-my-modal-child',
  templateUrl: './my-modal-child.component.html',
  styleUrls: ['./my-modal-child.component.css']
})
export class MyModalChildComponent implements OnInit {
  @Input() private display: string = 'none';  
  @Input('header-caption') private header: string = 'Modal';  
  constructor() { }

  ngOnInit() {
  }

  private fnClose(): void {  
    this.display = 'none';  
}  

showModal(): void {  
    this.display = 'block';  
}  

close(): void {  
    this.fnClose();  
}  

setModalTitle(args: string): void {  
    this.header = args;  
}  
}
