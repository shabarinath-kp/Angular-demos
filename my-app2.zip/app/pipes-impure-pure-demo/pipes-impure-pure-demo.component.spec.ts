import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PipesImpurePureDemoComponent } from './pipes-impure-pure-demo.component';

describe('PipesImpurePureDemoComponent', () => {
  let component: PipesImpurePureDemoComponent;
  let fixture: ComponentFixture<PipesImpurePureDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PipesImpurePureDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PipesImpurePureDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
