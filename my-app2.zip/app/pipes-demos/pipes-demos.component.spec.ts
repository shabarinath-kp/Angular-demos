import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PipesDemosComponent } from './pipes-demos.component';

describe('PipesDemosComponent', () => {
  let component: PipesDemosComponent;
  let fixture: ComponentFixture<PipesDemosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PipesDemosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PipesDemosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
