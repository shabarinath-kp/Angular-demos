import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes-demos',
  templateUrl: './pipes-demos.component.html',
  styleUrls: ['./pipes-demos.component.css']
})
export class PipesDemosComponent implements OnInit {

  text:string;
  text2:string;
  
  num1 = 12.638467846; 

  today =new Date();


  rows = 
  {
    a: 1,
    b: 2
  }

  

  constructor() { }

  ngOnInit() {
    this.text="sldfjlsdfjlsdjf";
    this.text2="AADFDFSDFSDFSFDF";
  }

}
