import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-parent',
  templateUrl: './content-parent.component.html',
  styleUrls: ['./content-parent.component.css']
})
export class ContentParentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
