import { BrowserModule } from '@angular/platform-browser';
import { NgModule   } from '@angular/core';

import { AppComponent } from './app.component';
import { ChangeColorDirective } from './change-color.directive';
import { LifeCycleParentComponent } from './life-cycle-parent/life-cycle-parent.component';
import { LifeCycleChildComponent } from './life-cycle-child/life-cycle-child.component';
import { MyModalParentComponent } from './ng-content-demos/my-modal-parent/my-modal-parent.component';
import { MyModalChildComponent } from './ng-content-demos/my-modal-child/my-modal-child.component';
import { SamplePipe } from './sample.pipe';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FilterSortDemoComponent } from './filter-sort-demo/filter-sort-demo.component';
import { SortByPipePipe } from './sort-by.pipe';
import { FilterPipePipe } from './fcustom-filter.pipe';
import { PipesImpurePureDemoComponent } from './pipes-impure-pure-demo/pipes-impure-pure-demo.component';
import { ImPureSortPipe, PureSortPipe } from './pure-impure.pipe';
import { ContentParentComponent } from './content-parent/content-parent.component';
import { ContentChildComponent } from './content-child/content-child.component';
import { PipesDemosComponent } from './pipes-demos/pipes-demos.component';
import { CapitalizePipe } from './capitalize.pipe';
 
@NgModule({
  declarations: [
    AppComponent,
    ChangeColorDirective,
    LifeCycleParentComponent,
    LifeCycleChildComponent,
    MyModalParentComponent,
    MyModalChildComponent,
    SamplePipe,
    FilterSortDemoComponent,
    SortByPipePipe,
    FilterPipePipe,
    PipesImpurePureDemoComponent,
    PureSortPipe,
    ImPureSortPipe,
    ContentParentComponent,
    ContentChildComponent,
    PipesDemosComponent,
    CapitalizePipe
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
   
})
export class AppModule { }
