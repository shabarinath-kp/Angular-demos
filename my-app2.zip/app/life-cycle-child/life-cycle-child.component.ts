import { Component, 
  OnInit,
  Input ,
  OnChanges, 
  SimpleChanges, 
  DoCheck, 
  AfterContentInit, 
  AfterContentChecked,
  AfterViewInit, 
  AfterViewChecked, 
  OnDestroy
} from '@angular/core';

@Component({
  selector: 'app-life-cycle-child',
  templateUrl: './life-cycle-child.component.html',
  styleUrls: ['./life-cycle-child.component.css']
})
export class LifeCycleChildComponent implements OnInit,
OnChanges,DoCheck,
AfterContentInit,
AfterContentChecked,
AfterViewInit,
AfterViewChecked,
OnDestroy 
{
  
  @Input() dataFrmParent:string;

  constructor() {
    console.group("Inside Child Cmp constructor");
       console.log("data from parent is " + this.dataFrmParent);
    console.groupEnd();

   }

   ngOnChanges(changes: SimpleChanges): void 
   {
    console.group("Inside Child Cmp  -OnChanges");
    console.log('In ngOnChanges '+this.dataFrmParent);
    for (const key in changes) {
        console.log(`${key} changed.
         Current : ${changes[key].currentValue}
         Previous : ${changes[key].previousValue}`);
    }
    console.groupEnd(); 
  }

  ngOnInit(): void 
  {
    console.group("Inside Child Cmp  -ngOnInit");
    console.log(" ngOnInit  "+this.dataFrmParent);
    console.groupEnd(); 
  }

  ngDoCheck(): void 
  {
    console.group("Inside Child Cmp  -ngDoCheck");
    console.log("In ngDoCheck");
    console.groupEnd(); 
  }

  ngAfterContentInit(){
    console.group("Inside Child Cmp  -ngDoCheck");
    console.log("In ngAfterContentInit");
    console.groupEnd(); 
  }

  ngAfterContentChecked(){
    console.group("Inside Child Cmp  -ngAfterContentChecked");
    console.log("In ngAfterContentChecked");
    console.groupEnd(); 
  }

  ngAfterViewInit()
  {
    console.group("Inside Child Cmp  -ngAfterViewInit");
    console.log("In ngAfterViewInit");
    console.groupEnd(); 
  }

  ngAfterViewChecked(){
    console.group("Inside Child Cmp  -ngAfterViewChecked");
    console.log("In ngAfterViewChecked");
    console.groupEnd(); 
  }

  ngOnDestroy()
  {
    console.group("Inside Child Cmp  -ngOnDestroy");
    console.log("In ngOnDestroy");
    console.groupEnd(); 
  }
  

}
